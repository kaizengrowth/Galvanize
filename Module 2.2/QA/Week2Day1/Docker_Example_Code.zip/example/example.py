import time

while True:
    print("We are cooking....")
    time.sleep(1)