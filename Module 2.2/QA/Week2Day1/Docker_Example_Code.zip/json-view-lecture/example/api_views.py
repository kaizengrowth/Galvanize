from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
import json

from .models import Blog
from .acls import get_fun_fact

@require_http_methods(["GET", "POST"])
def list_blogs(request):
    if request.method == "GET":
        blogs = Blog.objects.all()
        response = []
        for blog in blogs:
            response.append({
                "title": blog.title,
                "href": blog.get_api_url()
            })
        return JsonResponse({"blogs": response})
    else:
        content = json.loads(request.body)

        fact = get_fun_fact()
        content.update(fact)

        blog = Blog.objects.create(**content)
        return JsonResponse({
          "href": blog.get_api_url(),
          "title": blog.title,
          "content": blog.content,
          "answer": blog.answer,
          "question": blog.question,
          "category": blog.category,
          "comments": [],
        })


@require_http_methods(["DELETE", "GET", "PUT"])
def show_blog_detail(request, pk):
    if request.method == "GET":
        blog = Blog.objects.get(id=pk)
        comments = [
            {"id": c.id, "content": c.content}
            for c in blog.comments.all()
        ]
        response = {
            "title": blog.title,
            "content": blog.content,
            "comments": comments,
            "answer": blog.answer,
            "question": blog.question,
            "category": blog.category,
        }
        return JsonResponse(response)
    elif request.method == "DELETE":
        count, _ = Blog.objects.filter(id=pk).delete()
        return JsonResponse({"deleted": count > 0})
    else:
        content = json.loads(request.body)
        Blog.objects.filter(id=pk).update(**content)
        blog = Blog.objects.get(id=pk)
        comments = [
            {"id": c.id, "content": c.content}
            for c in blog.comments.all()
        ]
        response = {
            "href": blog.get_api_url(),
            "title": blog.title,
            "content": blog.content,
            "answer": blog.answer,
            "question": blog.question,
            "category": blog.category,
            "comments": comments,
        }
        return JsonResponse(response)
