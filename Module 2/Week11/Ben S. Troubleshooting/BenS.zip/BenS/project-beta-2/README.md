# CarCar

Team:

* Leo  Galvan- Sales
* Ben - Service

## Design

## Service microservice

Explain your models and integration with the inventory
microservice, here.

## Sales microservice

Explain your models and integration with the inventory
microservice, here.
