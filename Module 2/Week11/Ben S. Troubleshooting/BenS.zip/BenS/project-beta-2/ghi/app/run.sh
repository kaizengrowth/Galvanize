npm install
npm start
