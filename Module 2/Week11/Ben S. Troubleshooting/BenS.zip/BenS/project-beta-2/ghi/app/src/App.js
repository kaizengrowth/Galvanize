import { BrowserRouter, Routes, Route } from 'react-router-dom';
import MainPage from './MainPage';
import Nav from './Nav';
import TechnicianForm from './ServiceJS/EnterTechnicianForm';
import AppointmentForm from './ServiceJS/EnterAppointment';
import AppointmentList from './ServiceJS/ListOfAppointments';

function App() {
  return (
    <BrowserRouter>
      <Nav />
      <div className="container">
        <Routes>
          <Route path="/" element={<MainPage />} />

          <Route path = "technicians/new" element={<TechnicianForm />} />

          <Route path = "service_appointment/">
            <Route index element={<AppointmentList />} />
            <Route path = "new/" element={<AppointmentForm />} />
          </Route>

        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
