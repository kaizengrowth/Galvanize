import React from 'react';

class AppointmentForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            customer_name: '',
            tech_name: '',
            technicians: [],
            appointment_date: '',
            appointment_time: '',
            service_reason: '',
            vin: '',
            vip: '',
        };

        this.handleFieldChange = this.handleFieldChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChangeCustomerName = this.handleChangeCustomerName.bind(this);
        this.handleChangeTechName = this.handleChangeTechName.bind(this);
        this.handleChangeDate = this.handleChangeDate.bind(this);
        this.handleChangeTime = this.handleChangeTime.bind(this);
        this.handleChangeService = this.handleChangeService.bind(this);
        this.handleChangeVIN = this.handleChangeVIN.bind(this);
        this.handleChangeVIP = this.handleChangeVIP.bind(this);
    }

    handleFieldChange(event) {
        this.setState({
            ...this.state, [event.target.name]: event.target.value
        })
    }

    async handleSubmit(event) {
        event.preventDefault();
        const data = {...this.State};

        const serviceURL = 'http://localhost:3000/service_appointment/new/';
        const fetchConfig = {
            method: 'POST',
            body: JSON.stringify(data),
            headers: {
                'Content-Type': 'application/json',
            }
        }
        const response = await fetch(serviceURL, fetchConfig);
        if (response.ok) {
          const newAppointment = await response.json();
          console.log(newAppointment);
          this.setState({
                customer_name: '',
                tech_name: '',
                appointment_date: '',
                appointment_time: '',
                service_reason: '',
                vin: '',
                vip: '',
      });
    }
}

    handleChangeTechName(event) {
        const value = event.target.value;
        this.setState({ tech_name: value});
    }

    handleChangeDate(event) {
        const value = event.target.value;
        this.setState({ appointment_date: value});
    }

    handleChangeTime(event) {
        const value = event.target.value;
        this.setState({ appointment_time: value});
    }

    handleChangeService(event) {
        const value = event.target.value;
        this.setState({ service_reason: value});
    }

    handleChangeCustomerName(event) {
        const value = event.target.value;
        this.setState({ customer_name: value});
    }

    handleChangeVIN(event) {
        const value = event.target.value;
        this.setState({ vin: value});
    }

    handleChangeVIP(event) {
        const value = event.target.value;
        this.setState({ vip: value});
    }

    async componentDidMount() {

        const technicians = "http://localhost:8080/api/technicians/";
        const response = await fetch(technicians);
        if (response.ok) {
            const data = await response.json();
            this.setState({
                technicians: data.technician });
        }
    }

render() {

    console.log("below render : " + this.state.technicians)
    return (
      <div className="row">
        <div className="offset-3 col-6">
          <div className="shadow p-4 mt-4">
            <h1>Enter a Service Appointment</h1>
            {/* <image  */}
            <form onSubmit={this.handleSubmit} id="create-conference-form">

              <div className="form-floating mb-3">
                <input onChange={this.handleChangeCustomerName} value={this.state.customer_name} placeholder="Customer Name" required type="text" name="name" id="name" className="form-control" />
                <label htmlFor="name">Customer Name</label>
              </div>


              <div className="form-floating mb-3">
                <select onChange={this.handleChangeTechName} value={this.state.tech_name} placeholder="Tech Name" required name="tech name" id="tech name" className="form-select">
                    <option value="defaultValue">Choose a Tech</option>
                    {console.log(this.state)}
                    {this.state.technicians.map(technician => {
                        return (
                            <option key={technician.id} value={technician.employee_number}>{technician.tech_name}</option>
                        )
                    })}
                </select>
                </div>


              <div className="form-floating mb-3">
                <input onChange={this.handleChangeDate} value={this.state.appointment_date} placeholder="Ends" required type="date" name="appointment date" id="appointment date" className="form-control" />
                <label htmlFor="appointment_date">Appointment Date</label>
              </div>

              <div className="form-floating mb-3">
                <input onChange={this.handleChangeTime} value={this.state.appointment_time} placeholder="Appointment Time" required type="text" id="appointment time" name="appointment time" className="form-control" />
                <label htmlFor="appointment_time">Appointment Time</label>
              </div>

              <div className="form-floating mb-3">
                <input onChange={this.handleChangeService} value={this.state.service_reason} placeholder="Service Reason" required type="text" name="Service Reason" id="Service Reason" className="form-control" />
                <label htmlFor="service_reason">Service Reason</label>
              </div>

              <div className="form-floating mb-3">
                <input onChange={this.handleChangeVIN} value={this.state.vin} placeholder="VIN" required type="text" name="vin" id="vin" className="form-control" />
                <label htmlFor="vin">VIN</label>
              </div>

              <div className="form-floating mb-3">
                <input onChange={this.handleChangeVIP} value={this.state.vip} placeholder="VIP" required type="text" name="vip" id="vip" className="form-control" />
                <label htmlFor="vip">VIP?</label>
              </div>

              <button className="btn btn-success">Create</button>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default AppointmentForm;