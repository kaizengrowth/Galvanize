from django.apps import AppConfig


class SalesRestConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sales_rest'
