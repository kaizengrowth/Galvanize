# Become a Django Developer (Learning Path)

Tags: Django, Educative, FastAPI, Python
URL: https://www.educative.io/path/become-a-django-developer

## CONTENTS

1. [Django Web App Setup](https://www.notion.so/Become-a-Django-Developer-Learning-Path-19de263243ce425d8482ae9186609a10)
2. Django Basics
    
    a)  [Django Admin Site](https://www.notion.so/Become-a-Django-Developer-Learning-Path-19de263243ce425d8482ae9186609a10)
    
    b). [Application Model](https://www.notion.so/Become-a-Django-Developer-Learning-Path-19de263243ce425d8482ae9186609a10)
    

---

# 1.    Django Web App Setup

Starting a new project:

```bash
django-admin startproject [projectname] .
python manage.py startapp [appname]
```

The default database used by Django is the **SQLite3** database. The following piece of code is generated whenever we set up a new Django web app.

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}
```

To use the PostgreSQL database, we need to modify the `DATABASES`field in the ***settings.py*** as follows:

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': '<database_name>',
        'USER': '<database_username>',
        'PASSWORD': '<database_password>',
        'HOST': 'localhost',
        'PORT': '<port>',
    }
}
```

### Static files

Static files refer to the files containing images, logos, JavaScript code, CSS files, and more.

**`STATIC_URL`**

Django will use this path and append it to the base URL of our website. For example, `http://websitename/static/style.css`. This references static files during development.

**`STATICFILES_DIRS`**

Refers to the location of static files in our project. We can have different paths listed if you have any additional directories that contain static files. tells Django to look for extra static files in the specified paths.

**`STATIC_ROOT`**

Refers to the absolute path from which Django will collect static files during production. It’s not recommended to serve static files from your own local project, which is why we need to include this path during production.

### **Media files**

Refers to the files uploaded by users.

**`MEDIA_URL`**

Similar to `STATIC_URL` but refers to media files instead of static ones.

**`MEDIA_ROOT`**

Refers to the absolute path that points to the directory that will hold user-uploaded files.

**`FILE_UPLOAD_PERMISSIONS`**

Sometimes, Python throws an error regarding what users can do when an image is uploaded. In order to avoid inconsistencies with file permissions, please set `FILE_UPLOAD_PERMISSIONS = 0O640`.

---

# 2.    Django Basics

## a).   Django Admin Site

To access the admin panel, we need to create admin credentials first.

```bash
python manage.py createsuperuser
```

![Screen Shot 2022-09-21 at 1.16.15 PM.png](Become%20a%20Django%20Developer%20(Learning%20Path)%2019de263243ce425d8482ae9186609a10/Screen_Shot_2022-09-21_at_1.16.15_PM.png)

Issue the command `python manage.py runserver`to run the app. 

To see the login page for the Django admin site, we need to append `/admin/`at the end of our base URL. For example, if our app is running at `http://127.0.0.1:8000`, we can access the admin panel at `http://127.0.0.1:8000/admin/`.

## b).  Application Model

Add the application as a class in `models.py`

### `**=== [models.py](http://models.py) ===**`

```python
from django.db import models
from django.utils.timezone import now
from datetime import datetime

class Listings(models.Model):

    class SaleType(models.TextChoices):
        PICK_UP = "Available for pickup"
        SHIP = "Available for shipping"

    class ConditionType(models.TextChoices):
        USED = "Used"
        NEW = "New"

    class ProductType(models.TextChoices):
        BIKE = "Bike"
        PARTS = "Parts"
        MODELS = "Models"
        OTHER = "Other"

  
    title = models.CharField(max_length=100)
    condition = models.CharField(
        max_length=50, choices=ConditionType.choices, default=ConditionType.USED)
    product_type = models.CharField(
        max_length=50, choices=ProductType.choices, default=ProductType.BIKE)
    sale_type = models.CharField(
        max_length=50, choices=SaleType.choices, default=SaleType.SHIP)
    price = models.FloatField()
    address = models.CharField(max_length=100)
    city = models.CharField(max_length=25)
    state = models.CharField(max_length=25)
    zipcode = models.CharField(max_length=25)
    main_photo = models.ImageField()
    photo_1 = models.ImageField()
    photo_2 = models.ImageField(blank=True)
    list_date = models.DateTimeField(default=now)
    contact_email = models.CharField(max_length=50)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name_plural = "Listings"
```

Every model that we create will inherit from `django.db.models.Model`. In other words, each model is a subclass of this import.

We also import datetime and timezones, to retrieve current time for each user based on individual timezones.

### Field Types:

**`CharField`**

Used for small to large-sized strings.

**`ImageField`**

This class has the same attributes and methods from `FileField`, but also checks whether the uploaded file is a valid image. The `FileField` class can also be used to upload images.

**`DateTimeField`**

Used to display date and time.

**`FloatField`**

Used for floating-point numbers.

**`TextChoices`**

This is a subclass of the `Choices` class which allows us to display string choices.

**`blank`**

By default, `blank` is set to `False` which means that the field will appear as mandatory. This means that if the field is not filled out, the form won’t be submitted.

When `blank` is set to `True`, users can leave the field empty and the form will still be submitted successfully.

**`__str__`**

This method allows us to convert an object into a string. The string representation will be displayed in the admin panel alongside the field of the object that we return (in this case, the `title` field).

### Register the Model in admin.py

### `**=== admin[.py](http://models.py) ===**`

```python
from django.contrib import admin
from .models import Listings

admin.site.register(Listings)
```

### Migration

Once we’ve made the respective changes to ***models.py***, issue the migration commands and run the server.

```
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```