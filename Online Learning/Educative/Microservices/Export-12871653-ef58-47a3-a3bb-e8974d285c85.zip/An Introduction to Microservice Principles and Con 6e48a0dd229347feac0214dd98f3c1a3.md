# An Introduction to Microservice Principles and Concepts

Tags: Bounded Contexts, Docker, Domain-Driven Design, Educative, Microservices
URL: https://www.educative.io/courses/introduction-microservice-principles-concepts

**CONTENTS**

[Preface](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3.md)

[Microservices](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3.md)

# I.    Preface

Microservices require solutions for different challenges: 

1. **Integration** - frontend, synchronous & asynchronous microservices
2. **Operation** - monitoring, log analysis, tracing

Micro & Macro

Docker for Microservices

# II.    Microservices

**Microservices** - independently deployable modules

- Speeds up deployment
- Reduces the number of necessary tests

### **Advantages:**

1. **Easy scalability of deployment**
    1. Internal structure of Docker container doesn’t matter as long as the interface is present and functions correctly. 
    2. Teams can make independent decisions, including programming languages.
    3. Individual features can be brought into production on its own.

 2. **Replacing legacy systems**

1. Can replace parts of the old system with integration between old system and new microservices: data replication, REST, messaging, or at level of UI.
2. New microservices can be like a greenfield project (no old constraints), and devs can employ a new tech stack.

1. **Sustainable development**
    1. Replaceability of microservices - when a microservice can no longer be maintained, it can be rewritten.
    2. In order to do this, the **dependencies between microservices have to be managed appropriately.**

### Managing Dependencies

1. **Classical Architecture** - more dependencies are introduced over time; original design architecture becomes more violated, culminating in completely unstructured system
2. **Microservices Architecture** - clear boundaries due to their interface, so unlikely that architecture violations will occur at the level of dependencies between microservices (interfaces are architecture firewalls).

### Continuous Delivery Pipeline

Commit —> Acceptance Tests —> Capacity Tests —>  Explorative Tests —> Production

**PHASES**
1.  **Commit Phase** - software compilation, unit tests, static code analysis

2. **Acceptance Tests Phase** - automated tests to assure correctness of software regarding domain logic

1. **Capacity Tests Phase** - check performance at expected load
2. **Explorative Tests Phase** - analyze new functionalities or aspects that are not yet covered by automated tests
3. **Production Phase**

**Microservices facilitate continuous delivery:**

- Continuous delivery pipeline is faster because deployment units are smaller.