# An Introduction to Microservice Principles and Concepts

Tags: Anti-corruption layer, Bounded Contexts, Docker, Domain-Driven Design, Educative, Microservices
URL: https://www.educative.io/courses/introduction-microservice-principles-concepts

**CONTENTS**

[Preface](https://www.notion.so/An-Introduction-to-Microservice-Principles-and-Concepts-6e48a0dd229347feac0214dd98f3c1a3)

[Microservices](https://www.notion.so/An-Introduction-to-Microservice-Principles-and-Concepts-6e48a0dd229347feac0214dd98f3c1a3)

[Micro & Macro Architecture](https://www.notion.so/An-Introduction-to-Microservice-Principles-and-Concepts-6e48a0dd229347feac0214dd98f3c1a3)

[Migration](https://www.notion.so/An-Introduction-to-Microservice-Principles-and-Concepts-6e48a0dd229347feac0214dd98f3c1a3)

[Docker](https://www.notion.so/An-Introduction-to-Microservice-Principles-and-Concepts-6e48a0dd229347feac0214dd98f3c1a3)

# I.    Preface

Microservices require solutions for different challenges: 

1. **Integration** - frontend, synchronous & asynchronous microservices
2. **Operation** - monitoring, log analysis, tracing

Micro & Macro

Docker for Microservices

# II.    Microservices

**Microservices** - independently deployable modules

- Speeds up deployment
- Reduces the number of necessary tests

### **Advantages:**

1. **Easy scalability of deployment**
    1. Internal structure of Docker container doesn’t matter as long as the interface is present and functions correctly. 
    2. Teams can make independent decisions, including programming languages.
    3. Individual features can be brought into production on its own.

 2. **Replacing legacy systems**

1. Can replace parts of the old system with integration between old system and new microservices: data replication, REST, messaging, or at level of UI.
2. New microservices can be like a greenfield project (no old constraints), and devs can employ a new tech stack.

1. **Sustainable development**
    1. Replaceability of microservices - when a microservice can no longer be maintained, it can be rewritten.
    2. In order to do this, the **dependencies between microservices have to be managed appropriately.**

1. **Robustness**
    1. When a memory leak exists, only the specific microservice is affected and crashes. Others compensate for the failure of the crashed microservice (resilience).
    2. To achieve resilience, microservices can cache values and use them in case of a problem, or fallback to a simplified algorithm. 

1. **Independent Scaling, Free Technology Choice, Security**
    1. Scaling the whole system is not required.
    2. Each microservice can be implemented with a different technology; simpler and less risky to gain experience with new technologies.
    3. Introduce firewalls between microservices and encrypt communication to prevent corruption of additional microservices if hacker takes over one.
    4. Stronger isolation enables all of these advantages. Decoupling makes security easier to verify, performance easier to measure, and makes design/development easier.

### Managing Dependencies

1. **Classical Architecture** - more dependencies are introduced over time; original design architecture becomes more violated, culminating in completely unstructured system
2. **Microservices Architecture** - clear boundaries due to their interface, so unlikely that architecture violations will occur at the level of dependencies between microservices (interfaces are architecture firewalls).

### Continuous Delivery Pipeline

![Screen Shot 2022-09-17 at 5.07.51 PM.png](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3/Screen_Shot_2022-09-17_at_5.07.51_PM.png)

**PHASES**
1.  **Commit Phase** - software compilation, unit tests, static code analysis

2. **Acceptance Tests Phase** - automated tests to assure correctness of software regarding domain logic

1. **Capacity Tests Phase** - check performance at expected load
2. **Explorative Tests Phase** - analyze new functionalities or aspects that are not yet covered by automated tests
3. **Production Phase**

**Microservices facilitate continuous delivery:**

- Continuous delivery pipeline is faster because deployment units are smaller.
- Tests need to cover fewer functionalities.
- Setting up CD pipeline is faster and takes less powerful hardware to run.
- Deployment of a microservice poses smaller risk than deployment of a monolith.

**However, deployment must be automated!** 

- Integration tests conflict with microservice independence and introduce dependencies between the CD pipelines. So integration tests must be reduced to a minimum.

**Two levels of microservices: domain and technical**

- Course-grained division by domain
- For technical reasons, some microservices can be further divided

### Challenges of Microservice Architecture

1. Operation requires more effort. Feasible when operation is largely automated.
2. Must be independently deployable.
3. Testing must be independent.
4. Changes that affect multiple microservices are more difficult to implement.
5. Compared to local communication, microservices that communicate through a network experience higher latency, and higher likelihood of failure. Microservice system relies on availability of other microservices.

# III.    Micro & Macro Architecture

- The **micro architecture** comprises all decisions that can be made individually for each microservice.
- The **macro architecture** consists of all decisions that can be made at a global level and apply to all microservices.

## Domain-Driven Design & Bounded Contexts

**Domain-driven design (DDD)** offers a collection of **patterns** for the domain model of a system.

Each domain model is valid only in a **bounded context**.

For the communication between bounded contexts, we can use **domain events**.

**Strategic Design** - the integration of bounded contexts.

![Screen Shot 2022-09-17 at 5.21.26 PM.png](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3/Screen_Shot_2022-09-17_at_5.21.26_PM.png)

The upstream team can influence the success of the downstream team, but not the other way around. For example, the success of the team responsible for payment depends on the order process team. If data such as prices or credit card numbers are not part of the order, it is impossible to do the payment. However, the order process does not depend on the payment to be successful. Therefore, **order processing is upstream**. It can make payment fail. **Payment is downstream** since it cannot make the order process fail.

1. ****The customer/supplier pattern -**** the supplier is upstream
 and the customer is downstream. 
.
    
    ![Screen Shot 2022-09-17 at 5.24.41 PM.png](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3/Screen_Shot_2022-09-17_at_5.24.41_PM.png)
    
    In the drawing above, for example, payment uses the model of the order process. However, payment defines requirements for the order process. Payment can only be done successfully if the order process provides the required data.
    
    So, payment can become a customer of the order process. That way the customer’s requirements can be included in the planning of the order process.
    
    A pattern like *customer/supplier* may **not be desirable as it **requires a lot of coordination.**
    
2. ****The conformist pattern -**** a bounded context simply uses a domain model from another bounded context.
    
    ![Screen Shot 2022-09-17 at 5.27.18 PM.png](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3/Screen_Shot_2022-09-17_at_5.27.18_PM.png)
    

The data warehouse team could not demand additional information from the other bounded context. However, it is still possible that they would receive additional information out of altruism. Essentially, the data warehouse team is not deemed important enough to get a more powerful role.

1. **The anti-corruption layer** pattern - the bounded context does not directly use the domain model of the other bounded context, but contains a layer for decoupling its own domain model from the model of the bounded context. This is useful in conjunction with the conformist pattern to generate a separate model decoupled from the first. 

![Screen Shot 2022-09-17 at 5.30.57 PM.png](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3/Screen_Shot_2022-09-17_at_5.30.57_PM.png)

1. **The separate ways** pattern - the bounded contexts are not related at the software level; the systems are independent and can be evolved completely independently.
    
    ![Screen Shot 2022-09-17 at 5.32.50 PM.png](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3/Screen_Shot_2022-09-17_at_5.32.50_PM.png)
    
2. The **shared kernel** pattern - a common core shared by multiple bounded contexts. i.e. the data of a customer. The shared kernel comprises shared business logic and shared database schema, therefore it is an anti-pattern for microservice environments, but can be used in deployment monoliths that follow DDD.
    
    ![Screen Shot 2022-09-17 at 5.34.46 PM.png](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3/Screen_Shot_2022-09-17_at_5.34.46_PM.png)
    
    1. The **open host service** pattern - the bounded context offers a generic interface with several services. Other bounded contexts can implement their own integration with these services. Frequently found at public API’s on the internet. 
    
    2. The **published language** model - domain model accessible by all bounded contexts. Such as the EDIFACT for transactions between companies. 
        
        ![Screen Shot 2022-09-17 at 5.38.11 PM.png](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3/Screen_Shot_2022-09-17_at_5.38.11_PM.png)
        
        The choice of patterns has to be in line with:
        
        1. The domain
        2. The power structures
        3. The communication relationships between the teams.
        
    
    ## Architecture Decisions
    
    Programming languages, frameworks, and infrastructure can be defined for each **microservice** individually at the **micro architecture** or uniformly across the **macro architecture.** 
    
    DATABASES
    
    **Micro**: Each microservice can also have its own instance of the database. If databases were defined at the **micro architecture**. A crash of one database will cause only one microservice to fail which makes the entire app **more robust**.
    
    **Macro**: To avoid needing many different databases, the database can be defined as part of the **macro architecture** for all microservices. Even if the database is defined in the macro architecture, **multiple microservices must not share a database schema**. That would contradict the [bounded contexts](https://www.educative.io/collection/page/10370001/6518081205567488/4953894968885248).
    
    USER INTERFACE
    
    Sometimes different UI’s for different users of a subsystem is fine. Other times, a uniform style guide is needed across parts of a system.
    
    DOCUMENTATION can also be micro or macro.
    
    ### Typical Macro Architecture Decisions
    
    1. **Communication Protocol** - ie REST interface or messaging interface; data format: JSON or XML
    2. **Authentication**
    3. **Integration Testing** 

### Typical Micro Architecture Decisions

1. **Authorization**
2. **Testing** (besides integration testing)

![Screen Shot 2022-09-17 at 5.52.33 PM.png](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3/Screen_Shot_2022-09-17_at_5.52.33_PM.png)

## Operation: Micro or Macro Architecture?

### 1. Configuration

Define the interface with which a microservice obtains its configuration parameters: ie. environmental variable or config file? Technical parameters such as thread pool sizes, parameters for domain logic. 

Configuring passwords or passwords is also a challenge that can be solved with tools like Vault.

### 2. Monitoring

### 3. Log Analysis

### 4. Deployent Technology

Docker, Kubernetes Pods, PaaS? 

**black box test -** checks the behavior of the microservice from the outside to test conformance of the macro architecture by deploying a microservice and checking its log output and metrics

## Independent System Architecture Recipes

- [Conditions](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Conditions)
- [Principle #1: The system must be divided into modules](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Principle-#1:-The-system-must-be-divided-into-modules) that offer interfaces.
    - [Evaluation](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Evaluation)
- [Principle #2: Two separate levels of architectural decisions](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Principle-#2:-Two-separate-levels-of-architectural-decisions)
    - [Evaluation](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Evaluation)
- [Principle #3: Modules must be separate processes/containers/VMs](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Principle-#3:-Modules-must-be-separate-processes/containers/VMs)
    - [Evaluation](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Evaluation)
- [Principle #4: Standardized integration & communication](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Principle-#4:-Standardized-integration-&-communication)
    - [Evaluation](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Evaluation)
- [Principle #5: Standardized metadata](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Principle-#5:-Standardized-metadata)
    - **Metadata** for example, for *authentication* **must be standardized** Otherwise, the user would need to log in to each microservice.
    - [Evaluation](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Evaluation)
- [Principle #6: Independent continuous delivery pipelines](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Principle-#6:-Independent-continuous-delivery-pipelines)
    - [Evaluation](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Evaluation)
- [Principle #7: Operations should be standardized](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Principle-#7:-Operations-should-be-standardized)
    - 
    - configuration
    - deployment
    - log analysis
    - tracing
    - monitoring
    - alarms
    - [Evaluation](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Evaluation)
- [Principle #8: Standardized interface](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Principle-#8:-Standardized-interface)
    - [Evaluation](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Evaluation)
- [Principle #9: Modules have to be resilient](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Principle-#9:-Modules-have-to-be-resilient)
    - [Evaluation](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Evaluation)
- [Summary](https://www.educative.io/courses/introduction-microservice-principles-concepts/B8VxE3kEOw2#Summary)

**[ISA](http://isa-principles.org/) (Independent Systems Architecture)** is the term for a collection of fundamental principles for microservices. It is based on experiences with microservices gained from many different projects.

# IV. Migration

Migration **from a deployment monolith to a microservices architecture**
 is the common case for introducing microservices.

## **A typical scenario**

A typical scenario for a migration to microservices is:

- The aim of the migration is to **increase the development speed**.
    - Microservices need fewer tests for a release and provide easier continuous delivery because they are smaller.
    - Also, the development of individual microservices is quite independent, so less time is spent on coordination. All of this can make development faster.
- The migration to microservices **must provide an advantage in development as quickly as possible**. It makes no sense to invest in an architectural change that only leads to improvement much later down the line.

The migration **strategy proposed** here is **based on extracting individual microservices** in order to achieve an improvement of the situation as quickly as possible.

![Screen Shot 2022-09-17 at 6.33.09 PM.png](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3/Screen_Shot_2022-09-17_at_6.33.09_PM.png)

## **Give a preference to asynchronous communication**

Integration with the legacy system should take place via asynchronous communication. This **decouples the domain logic of the microservice from the legacy system**.

The UI integration also **offers an easy way to operate the microservice and the legacy system in parallel**. Individual requests can be redirected to the microservices, while the remaining requests are still processed by the legacy system.

Often, there is a web server anyway which processes every request and carries out TLS/SSL termination, for example, parallel operation of microservices and the legacy system is then quite simple. The web server only has to forward each request either to a microservice or to the legacy system.

UI integration is particularly **easy if the legacy system is a web application**. But it is also possible, for example, to integrate web views in a mobile application to thereby integrate parts of the UI as web pages. In such cases, UI integration should really be considered as an option because of its many advantages.

## **Avoid synchronous communication**

Synchronous communication should be used sparingly. It **leads to a close dependence with regard to availability**. If the called system fails, the calling system must be able to deal with this. Synchronous communication may be necessary if you want the last changes to be visible in the other systems as soon as possible. In a synchronous call, the state at the time of the call is always used, whereas asynchronous communication and replication can lead to a delay until the current state is known everywhere.

## **Replicating data**

Even in a migration scenario, **each microservice should have its own database or at least its own database schema**. The goal of the migration is to achieve independent development and simple continuous delivery of the microservices. This is not possible if the microservices and the legacy system use the same database. Together with asynchronous communication, a separate database means **data replication.** This is the only way for the microservices to implement their own data model. **Changes to the data can be communicated via events**. Replication for a specific part of the data should take place in one direction only. Usually, replication can be done using business events – that is, events that have a meaning for a business expert. One system (a microservice or the legacy system) should trigger the events, and the other system reacts to the events.

The **legacy system can be gradually replaced by microservices**
. In the course of the migration, the focus should be on converting parts of the system into microservices that are currently undergoing major changes so that the migration to microservices is worthwhile. This is called the **[strangler pattern](https://www.martinfowler.com/bliki/StranglerApplication.html)**
. The microservices increasingly strangle the legacy system until nothing is left of the legacy system anymore. Have a look at the drawing below for a visual.

![Screen Shot 2022-09-17 at 6.51.19 PM.png](An%20Introduction%20to%20Microservice%20Principles%20and%20Con%206e48a0dd229347feac0214dd98f3c1a3/Screen_Shot_2022-09-17_at_6.51.19_PM.png)

**a suitable test strategy must be established**. This also requires the automated setup of test environments and the assurance that the tests are independent.

- For example, stubs that simulate microservices or the legacy system are useful for this purpose, as are [consumer-driven contract tests](https://martinfowler.com/articles/consumerDrivenContracts.html). They safeguard the requirements for the interfaces of microservices or legacy systems with the help of tests.

• **Kubernetes, PaaS, or Docker** are also interesting in a migration scenario. However, they represent a *new environment* that needs to be operated. It may, therefore, make sense to use a classical deployment and operation environment at least at the beginning to reduce the initial migration effort. In the long term, however, such environments have many advantages. In addition, of course, the old system can be operated in such an environment.

# V. Docker

- Docker and microservices are nearly synonymous. This chapter **explains why Docker fits so well with microservices**.
- Docker facilitates software installation. Important for this is the `Dockerfile`, which describes the installation of the software in a simple way.
- Docker Machine and Docker Compose support Docker on server systems and complex software environments with Docker.

Microservices must be scalable independently of each other. In the event of a crash, a microservice must not be allowed to make other microservices unavailable, too, and thus endanger the robustness of the whole system. Therefore, **microservices must at least be separate processes**. **Scalability can be guaranteed by multiple instances of a process**.

But processes are limited concerning scaling. If the processes all run on one server, then only a limited amount of hardware resources are available. Instead, the microservices should run in a cluster. Kubernetes and Cloud Foundry support running microservices in a cluster.

The **ideal solution** would be a **lightweight alternative to virtualization**, which possesses the isolation of virtual machines, but consumes as little resources as processes do and is similarly easy to operate.

### **Shared kernel[#](https://www.educative.io/courses/introduction-microservice-principles-concepts/xlzBRlAy5rq#Shared-kernel)**

Instead of having a complete virtual machine of their own, Docker containers *share* the *kernel* of the operating system on the Docker host. The Docker host is the system on which the Docker containers run. The processes from the containers, therefore, appear in the process table of the operating system on which the Docker containers are running.

### **Isolated network of Dockers[#](https://www.educative.io/courses/introduction-microservice-principles-concepts/xlzBRlAy5rq#Isolated-network-of-Dockers)**

The Docker containers have their **own network interface**. In this way, the **same port can be used in each Docker container**, and each container can use any number of ports.

The network interface is in a subnet where all Docker containers are accessible. The subnet is not accessible from the outside. This is at least the standard configuration of Docker.

The Docker network configuration offers many other alternatives. To still allow external access to a Docker container from the outside, **ports of a Docker container can be mapped to ports on the Docker host**. When mapping the ports of the Docker containers to the ports of the Docker host, be careful because each port of the Docker host can only be mapped to one port of a Docker container.